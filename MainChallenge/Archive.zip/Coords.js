"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Coords {
    constructor(i, j, visited = false, previous = null) {
        this.i = i;
        this.j = j;
        this.visited = visited;
        this.previous = previous;
    }
}
exports.Coords = Coords;
