"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Coords = /** @class */ (function () {
    function Coords(i, j) {
        this.i = i;
        this.j = j;
    }
    return Coords;
}());
exports.Coords = Coords;
