"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Action {
    constructor(actionType, coord) {
        this.actionType = actionType;
        this.coord = coord;
    }
    asMove() {
        return [this.actionType, this.coord.i, this.coord.j];
    }
}
exports.Action = Action;
