"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Action = /** @class */ (function () {
    function Action(actionType, coord) {
        this.actionType = actionType;
        this.coord = coord;
    }
    Action.prototype.asMove = function () {
        return [this.actionType, this.coord.i, this.coord.j];
    };
    return Action;
}());
exports.Action = Action;
