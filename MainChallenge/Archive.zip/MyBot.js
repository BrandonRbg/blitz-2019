"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var xmlrpc = require("xmlrpc");
var yargs = require("yargs");
var Bot_1 = require("./Bot");
var argv = yargs
    .number('p')
    .number('port')
    .argv;
var PORT = argv.port || argv.p || 4000;
var server = xmlrpc.createServer({ host: '0.0.0.0', port: PORT }, function () {
    console.log("Server listening on port " + PORT);
});
var agent = new Bot_1.Bot();
server.on('NotFound', function (method, params) {
    console.log('Method ' + method + ' does not exist');
});
// Handle method calls by listening for events with the method call name
server.on('initialize', function (err, _a, callback) {
    var board = _a[0], players = _a[1], timeLeft = _a[2];
    agent.initialize(board, players, timeLeft);
    callback(null, undefined);
});
server.on('play', function (err, _a, callback) {
    var percepts = _a[0], player = _a[1], step = _a[2], timeLeft = _a[3];
    var action = agent.play(percepts, player, step, timeLeft);
    callback(null, action.asMove());
});
