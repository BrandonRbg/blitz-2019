import * as _ from 'lodash';
import { Coords } from './Coords';
import { Action } from './Action';

export class Board {
    constructor(
        public pawns: Coords[],
        public goals: Coords[],
        public nbWalls: number[],
        public horizontalWalls: Coords[],
        public verticalWalls: Coords[],
        public rows: number,
        public cols: number,
        public size: number
    ) {
    }

    canMoveHere(action: Action): boolean {
        const isInBound = 0 <= action.coord.i
            && action.coord.i < this.size
            && 0 <= action.coord.j && action.coord.j < this.size;
        const isOnAnotherPlayer = _.some(this.pawns, (coords) => _.isEqual(action.coord, coords));

        return isInBound && !isOnAnotherPlayer;
    }

    getAction(player: number): Action {
        const coord = this.pawns[player];
        const goal = this.goals[player];
        const distance = Math.abs(goal.i - coord.i);
        const dest = new Coords(coord.i + (goal.i - coord.i) / distance, coord.j);
        if (this.pawns.filter(p => p.i === dest.i && p.j === dest.j).length !== 0) {
            dest.i++;
        }
        return new Action('P', dest);
    };

    private static convertRawCoords([i, j]: number[]): Coords {
        return new Coords(i, j);
    }

    static fromPercepts(percepts): Board {
        const pawns = percepts.pawns.map(Board.convertRawCoords);
        const goals = percepts.goals.map(Board.convertRawCoords);
        const horizontalWalls = percepts.horiz_walls.map(Board.convertRawCoords);
        const verticalWalls = percepts.verti_walls.map(Board.convertRawCoords);
        const {nbWalls, rows, cols, size} = percepts;

        return new Board(pawns, goals, nbWalls, horizontalWalls, verticalWalls, rows, cols, size);
    }
}
