"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Board_1 = require("./Board");
var Bot = /** @class */ (function () {
    function Bot() {
    }
    Bot.prototype.initialize = function (board, players, timeLeft) {
        console.log(board);
    };
    Bot.prototype.play = function (percepts, player, step, timeLeft) {
        console.log("Player " + player);
        console.log("Step " + step);
        var board = Board_1.Board.fromPercepts(percepts);
        return board.getAction(player);
    };
    ;
    return Bot;
}());
exports.Bot = Bot;
