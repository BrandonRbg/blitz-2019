"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Board_1 = require("./Board");
class Bot {
    initialize(board, players, timeLeft) {
        console.log(board);
    }
    play(percepts, player, step, timeLeft) {
        console.log("Player " + player);
        console.log("Step " + step);
        const board = Board_1.Board.fromPercepts(percepts);
        return board.getAction(player);
    }
    ;
}
exports.Bot = Bot;
