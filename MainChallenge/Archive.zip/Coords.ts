export class Coords {
    constructor(
        public i: number,
        public j: number
    ) {}
}
