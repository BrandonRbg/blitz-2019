"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _ = require("lodash");
var Coords_1 = require("./Coords");
var Action_1 = require("./Action");
var Board = /** @class */ (function () {
    function Board(pawns, goals, nbWalls, horizontalWalls, verticalWalls, rows, cols, size) {
        this.pawns = pawns;
        this.goals = goals;
        this.nbWalls = nbWalls;
        this.horizontalWalls = horizontalWalls;
        this.verticalWalls = verticalWalls;
        this.rows = rows;
        this.cols = cols;
        this.size = size;
    }
    Board.prototype.canMoveHere = function (action) {
        var isInBound = 0 <= action.coord.i
            && action.coord.i < this.size
            && 0 <= action.coord.j && action.coord.j < this.size;
        var isOnAnotherPlayer = _.some(this.pawns, function (coords) { return _.isEqual(action.coord, coords); });
        return isInBound && !isOnAnotherPlayer;
    };
    Board.prototype.getAction = function (player) {
        var coord = this.pawns[player];
        var goal = this.goals[player];
        var distance = Math.abs(goal.i - coord.i);
        var dest = new Coords_1.Coords(coord.i + (goal.i - coord.i) / distance, coord.j);
        if (this.pawns.filter(function (p) { return p.i === dest.i && p.j === dest.j; }).length !== 0) {
            dest.i++;
        }
        return new Action_1.Action('P', dest);
    };
    ;
    Board.convertRawCoords = function (_a) {
        var i = _a[0], j = _a[1];
        return new Coords_1.Coords(i, j);
    };
    Board.fromPercepts = function (percepts) {
        var pawns = percepts.pawns.map(Board.convertRawCoords);
        var goals = percepts.goals.map(Board.convertRawCoords);
        var horizontalWalls = percepts.horiz_walls.map(Board.convertRawCoords);
        var verticalWalls = percepts.verti_walls.map(Board.convertRawCoords);
        var nbWalls = percepts.nbWalls, rows = percepts.rows, cols = percepts.cols, size = percepts.size;
        return new Board(pawns, goals, nbWalls, horizontalWalls, verticalWalls, rows, cols, size);
    };
    return Board;
}());
exports.Board = Board;
