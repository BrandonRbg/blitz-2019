"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var express = require("express");
var yargs = require("yargs");
var dijkstra_1 = require("./dijkstra/dijkstra");
var app = express();
var argv = yargs
    .number('p')
    .number('port')
    .argv;
var PORT = argv.port || argv.p || 8010;
app.get('/microchallenge', function (req, res) {
    console.log('\n\n\n-------------------------- REQUEST LOGS STARTING HERE --------------------------');
    console.log('You can log stuff and download the logs from the UI in the replay section.');
    console.log("Here is the current problem:");
    console.log(req.query.problem); // problem is in json format
    console.log('---------------------------------------------------------------------------------');
    var problem = JSON.parse(req.query.problem);
    var dijkstra = new dijkstra_1.Dijkstra(problem);
    var result = dijkstra.findPath();
    res.send((result).toString());
});
app.listen(PORT, function () {
    console.log("Example app listening on port " + PORT + "!");
});
//# sourceMappingURL=MyBot.js.map