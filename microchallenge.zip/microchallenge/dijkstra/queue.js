"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Node = /** @class */ (function () {
    function Node(node, weight) {
        this.node = node;
        this.weight = weight;
    }
    return Node;
}());
exports.Node = Node;
var Queue = /** @class */ (function () {
    function Queue() {
        this.nodes = [];
    }
    Queue.prototype.add = function (node) {
        this.nodes.push(node);
        this.nodes.sort(function (a, b) {
            if (a.weight > b.weight) {
                return 1;
            }
            else {
                return -1;
            }
        });
    };
    Queue.prototype.remove = function (node) {
        this.nodes.splice(this.nodes.indexOf(node), 1);
    };
    Queue.prototype.dequeue = function () {
        var res = this.nodes[0];
        this.nodes.splice(0, 1);
        return res;
    };
    return Queue;
}());
exports.Queue = Queue;
//# sourceMappingURL=queue.js.map