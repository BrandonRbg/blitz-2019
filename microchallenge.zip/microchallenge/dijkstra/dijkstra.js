"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var queue_1 = require("./queue");
var Heap = require("heap");
var Dijkstra = /** @class */ (function () {
    function Dijkstra(graph) {
        this.graph = graph;
        this.init();
    }
    Dijkstra.prototype.findPath = function () {
        var begin = this.startingNodes[0];
        var end = this.startingNodes[1];
        var queue = new Heap(function (a, b) { return a.weight - b.weight; });
        var distance = {};
        var previous = {};
        var path = 0;
        for (var key in this.nodes) {
            if (+key === begin) {
                distance[key] = 0;
                queue.push(new queue_1.Node(+key, 0));
            }
            else {
                distance[key] = Infinity;
                queue.push(new queue_1.Node(+key, Infinity));
            }
        }
        var minWeight = Infinity;
        while (!queue.empty()) {
            var smallest = queue.pop();
            // Find the path
            if (smallest.node === +end) {
                var i = smallest;
                while (previous[+i.node]) {
                    path += this.nodes[+i.node].weight;
                    i = previous[+i.node];
                }
                break;
            }
            // Need distance!
            if (!smallest || distance[+smallest.node] === Infinity) {
                continue;
            }
            for (var neighbor in this.nodes[smallest.node].neighbors) {
                var dist = distance[+smallest.node] + this.nodes[smallest.node].neighbors[neighbor];
                if (dist < distance[+neighbor]) {
                    distance[+neighbor] = dist;
                    previous[+neighbor] = smallest;
                    queue.push(new queue_1.Node(+neighbor, dist));
                }
            }
        }
        return path;
    };
    Dijkstra.prototype.init = function () {
        this.nodes = {};
        this.startingNodes = [];
        for (var i = 0; i < this.graph.length; i++) {
            for (var j = 0; j < this.graph[i].length; j++) {
                this.nodes[j + i * this.graph.length] = { weight: this.graph[i][j], neighbors: this.findNeighbors(i, j) };
                if (!this.graph[i][j]) {
                    this.startingNodes.push(j + i * this.graph.length);
                }
            }
        }
    };
    Dijkstra.prototype.findNeighbors = function (x, y) {
        var neighbor = {};
        if (y > 0) {
            neighbor[(y - 1) + this.graph.length * x] = this.graph[x][y - 1];
        }
        if (y < this.graph[x].length - 1) {
            neighbor[(y + 1) + this.graph.length * x] = this.graph[x][y + 1];
        }
        if (x > 0) {
            neighbor[y + this.graph.length * (x - 1)] = this.graph[x - 1][y];
        }
        if (x < this.graph.length - 1) {
            neighbor[y + this.graph.length * (x + 1)] = this.graph[x + 1][y];
        }
        return neighbor;
    };
    return Dijkstra;
}());
exports.Dijkstra = Dijkstra;
//# sourceMappingURL=dijkstra.js.map